package hn.edu.ujcv.lab2
class Alumno() {
    var nombre:String
        get() {
            return nombre
        }
        set(value) {
            nombre=value
        }

    var cuenta:String
        get() {
            return cuenta
        }
        set(value) {
            cuenta=value
        }
    var correo:String
        get() {
            return correo
        }
        set(value) {
            correo=value
        }
}