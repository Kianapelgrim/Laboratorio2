package hn.edu.ujcv.lab2
class Clase(){
    var codigo: Int
        get() {
            return codigo
        }
        set(value) { codigo=value }
    var aula: Int
        get() {
            return aula
        }
        set(value) { aula=value }
    var hora: String
        get() {
            return hora
        }
        set(value) { hora=value }
    var nombre: String
        get() {
            return nombre
        }
        set(value) { nombre=value }
    var piso: Int
        get() {
            return piso
        }
        set(value) { piso=value }
    var seccion: Int
        get() {
            return seccion
        }
        set(value) { seccion=value }
}
